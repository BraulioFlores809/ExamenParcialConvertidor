package com.example.profesor.examen1_flores_lopez_braulio_emmanuel_6im8;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;

public class Correo extends AppCompatActivity {

    EditText cantidad;
    Double respuesta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_correo);

        cantidad = (EditText)findViewById(R.id.envio);

        Bundle recibo = new Bundle();

        recibo = getIntent().getExtras();
        respuesta = recibo.getDouble("convertido");

        cantidad.setText("Flores Lopez Braulio Emmanuel ," + respuesta);
    }

    public void onClickEnviar(View v)
    {
        String correo = cantidad.getText().toString();
        Intent correos = new Intent(Intent.ACTION_SEND);
        correos.setType("text/plain");
        correos.putExtra(Intent.EXTRA_SUBJECT, "Asunto: Examen primer parcial/resultado de la conversion");
        correos.putExtra(Intent.EXTRA_TEXT, correo);
        correos.putExtra(Intent.EXTRA_EMAIL, new String[] { "eoropezag@ipn.mx"} );
        startActivity(correos);

    }


}

